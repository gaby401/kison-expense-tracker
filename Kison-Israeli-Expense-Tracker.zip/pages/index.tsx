import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BarChart2, Wallet, Calendar, PieChart, FileDown, Filter } from "lucide-react";
import { useState } from "react";
import { BarChart, Bar, PieChart as Pie, Pie as PieSlice, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const sampleExpenses = [
  { name: 'שכירות', amount: 2900 },
  { name: 'אוכל', amount: 1000 },
  { name: 'תחבורה', amount: 215 },
  { name: 'ילדים', amount: 1825 },
  { name: 'בריאות', amount: 600 },
];

const sampleIncome = [
  { name: 'משכורת', amount: 11771 },
  { name: 'קצבאות', amount: 1200 },
];

export default function ExpenseTrackerUI() {
  const [filter, setFilter] = useState('');

  const handleExport = () => alert("נתונים יוצאו לקובץ Excel!");

  const filteredExpenses = sampleExpenses.filter(e => e.name.includes(filter));

  return (
    <div className="p-4 grid gap-4">
      <h1 className="text-2xl font-bold text-center">כיסון - Israeli Expense Tracker</h1>

      <Tabs defaultValue="expenses" className="w-full">
        <TabsList className="grid grid-cols-5 gap-2">
          <TabsTrigger value="expenses"><Wallet className="w-4 h-4 mr-1" />הוצאות</TabsTrigger>
          <TabsTrigger value="income"><BarChart2 className="w-4 h-4 mr-1" />הכנסות</TabsTrigger>
          <TabsTrigger value="calendar"><Calendar className="w-4 h-4 mr-1" />חודשי</TabsTrigger>
          <TabsTrigger value="report"><PieChart className="w-4 h-4 mr-1" />דוח</TabsTrigger>
          <Button variant="outline" onClick={handleExport} className="flex items-center gap-1 text-xs">
            <FileDown className="w-4 h-4" />ייצוא
          </Button>
        </TabsList>

        <TabsContent value="expenses">
          <Card>
            <CardContent className="grid gap-3 pt-4">
              <Input placeholder="סכום (₪)" type="number" />
              <Input placeholder="קטגוריה (למשל: אוכל, שכירות)" />
              <Input placeholder="תאריך (לדוגמה: 2025-05-09)" type="date" />
              <Button>הוסף הוצאה</Button>
              <div className="flex items-center gap-2 pt-2">
                <Filter className="w-4 h-4" />
                <Input placeholder="סנן לפי קטגוריה" value={filter} onChange={e => setFilter(e.target.value)} />
              </div>
              <ul className="text-sm list-disc pl-4">
                {filteredExpenses.map((e, i) => <li key={i}>{e.name}: ₪{e.amount}</li>)}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="income">
          <Card>
            <CardContent className="grid gap-3 pt-4">
              <Input placeholder="סכום הכנסה (₪)" type="number" />
              <Input placeholder="מקור (עבודה, ביטוח לאומי)" />
              <Input placeholder="תאריך" type="date" />
              <Button>הוסף הכנסה</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar">
          <Card>
            <CardContent className="text-center pt-4">
              <p>מבט חודשי יופיע כאן (כולל ארנונה, חשמל, גנים ועוד)</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="report">
          <Card>
            <CardContent className="pt-4 grid gap-4">
              <h2 className="text-center font-semibold">התפלגות הוצאות</h2>
              <ResponsiveContainer width="100%" height={250}>
                <Pie data={sampleExpenses} dataKey="amount" nameKey="name" outerRadius={80}>
                  {sampleExpenses.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={`hsl(${index * 50}, 70%, 60%)`} />
                  ))}
                </Pie>
              </ResponsiveContainer>

              <h2 className="text-center font-semibold">הכנסות מול הוצאות</h2>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={[{ name: 'סה"כ', income: 12971, expenses: 7840 }]}>
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="income" fill="#4ade80" />
                  <Bar dataKey="expenses" fill="#f87171" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
